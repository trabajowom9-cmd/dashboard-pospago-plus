/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { User } from 'firebase/auth';
import {
  initAuth,
  googleSignIn,
  logout,
  getAccessToken,
  setAccessToken,
} from './services/firebaseAuth';
import {
  fetchSpreadsheetMetadata,
  fetchSheetData,
  SheetTab,
  extractSpreadsheetId,
} from './services/googleSheets';
import {
  parseSheetData,
  ParsedDataset,
  KpiItem,
} from './utils/dataParser';
import { Header, ConnectionStatus } from './components/Header';
import { KpiCard } from './components/KpiCard';
import { ChartsSection } from './components/ChartsSection';
import { DataTable } from './components/DataTable';
import { FilterBar } from './components/FilterBar';
import { EmptyState } from './components/EmptyState';
import { ConnectionErrorState } from './components/ConnectionErrorState';
import { SheetConfigModal } from './components/SheetConfigModal';
import { BarChart, Clock, Database, Layers, ShieldCheck } from 'lucide-react';

const STORAGE_KEY_SHEET_ID = 'pospagos_plus_sheet_id';
const STORAGE_KEY_TAB_TITLE = 'pospagos_plus_tab_title';

export default function App() {
  // Estado de Autenticación
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);

  // Configuración de la Hoja
  const [spreadsheetId, setSpreadsheetId] = useState<string>(() => {
    return localStorage.getItem(STORAGE_KEY_SHEET_ID) || '';
  });
  const [tabTitle, setTabTitle] = useState<string>(() => {
    return localStorage.getItem(STORAGE_KEY_TAB_TITLE) || 'Hoja 1';
  });
  const [availableTabs, setAvailableTabs] = useState<SheetTab[]>([]);
  const [spreadsheetTitle, setSpreadsheetTitle] = useState<string>('');
  const [isConfigModalOpen, setIsConfigModalOpen] = useState(false);
  const [isTestingConfig, setIsTestingConfig] = useState(false);

  // Estado de Sincronización y Datos
  const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>('updating');
  const [statusMessage, setStatusMessage] = useState<string>('');
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [isUpdating, setIsUpdating] = useState<boolean>(false);

  // Datos Crudos y Parseados
  const [rawHeaders, setRawHeaders] = useState<string[]>([]);
  const [rawRows, setRawRows] = useState<(string | number | boolean | null)[][]>([]);
  const [dataset, setDataset] = useState<ParsedDataset | null>(null);

  // Filtros interactivos
  const [selectedAdvisor, setSelectedAdvisor] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');

  // Referencia para evitar solicitudes simultáneas concurrentes
  const isFetchingRef = useRef(false);

  // 1. Inicializar Auth
  useEffect(() => {
    const unsubscribe = initAuth(
      (currentUser, currentToken) => {
        setUser(currentUser);
        setToken(currentToken);
      },
      () => {
        setUser(null);
        setToken(null);
      }
    );
    return () => unsubscribe();
  }, []);

  // 2. Iniciar Sesión con Google
  const handleSignIn = async () => {
    try {
      setIsUpdating(true);
      const res = await googleSignIn();
      if (res) {
        setUser(res.user);
        setToken(res.accessToken);
        await loadData(spreadsheetId, tabTitle, res.accessToken);
      }
    } catch (err: any) {
      console.error('Error al iniciar sesión:', err);
      setStatusMessage(err.message || 'Error al autenticar');
      setConnectionStatus('error');
    } finally {
      setIsUpdating(false);
    }
  };

  // 3. Cerrar Sesión
  const handleSignOut = async () => {
    await logout();
    setUser(null);
    setToken(null);
  };

  // 4. Cargar datos desde Google Sheets (Solo Lectura)
  const loadData = useCallback(
    async (sheetId: string, tab: string, authToken: string | null = token) => {
      const cleanId = extractSpreadsheetId(sheetId);

      if (!cleanId) {
        setConnectionStatus('error');
        setStatusMessage('Ingresa el enlace o ID de tu Google Sheet');
        setIsConfigModalOpen(true);
        return;
      }

      if (isFetchingRef.current) return;
      isFetchingRef.current = true;
      setIsUpdating(true);
      setConnectionStatus('updating');

      try {
        // A. Cargar metadatos para obtener pestañas
        try {
          const meta = await fetchSpreadsheetMetadata(cleanId, authToken);
          setSpreadsheetTitle(meta.title);
          if (meta.tabs && meta.tabs.length > 0) {
            setAvailableTabs(meta.tabs);
            // Si la pestaña actual no está en la lista, usar la primera pestaña real
            const exists = meta.tabs.some((t) => t.title.toLowerCase() === tab.toLowerCase());
            if (!exists && meta.tabs[0]) {
              tab = meta.tabs[0].title;
              setTabTitle(tab);
              localStorage.setItem(STORAGE_KEY_TAB_TITLE, tab);
            }
          }
        } catch (metaErr) {
          // Si falla metadata, intentar consultar datos directamente
          console.warn('Metadatos no disponibles, intentando lectura directa de datos', metaErr);
        }

        // B. Cargar datos de la pestaña
        const result = await fetchSheetData(cleanId, tab, authToken);
        setRawHeaders(result.headers);
        setRawRows(result.rows);

        // C. Parsear datos y calcular indicadores
        const parsed = parseSheetData(result.headers, result.rows);
        setDataset(parsed);

        // D. Actualizar estados de éxito
        setConnectionStatus('connected');
        setStatusMessage('Conexión exitosa');
        setLastUpdated(new Date());
      } catch (err: any) {
        console.error('Error al consultar Google Sheets:', err);
        // Si ya teníamos datos en memoria, marcar como 'stale' (datos desactualizados)
        if (rawRows.length > 0) {
          setConnectionStatus('stale');
          setStatusMessage('Datos en memoria (error al actualizar)');
        } else {
          setConnectionStatus('error');
          setStatusMessage(err.message || 'Error de conexión con Google Sheets');
        }
      } finally {
        setIsUpdating(false);
        isFetchingRef.current = false;
      }
    },
    [token, rawRows.length]
  );

  // 5. Carga inicial
  useEffect(() => {
    if (spreadsheetId) {
      loadData(spreadsheetId, tabTitle, token);
    } else {
      setConnectionStatus('error');
      setStatusMessage('Debes configurar el enlace o ID de tu Google Sheet');
      setIsConfigModalOpen(true);
    }
  }, [spreadsheetId, tabTitle, token, loadData]);

  // 6. Actualización automática cada 30 segundos
  useEffect(() => {
    if (!spreadsheetId) return;

    const interval = setInterval(() => {
      // Solo actualiza automáticamente si no hay otra petición en curso
      if (!isFetchingRef.current) {
        loadData(spreadsheetId, tabTitle, token);
      }
    }, 30000); // 30 segundos

    return () => clearInterval(interval);
  }, [spreadsheetId, tabTitle, token, loadData]);

  // 7. Prueba de conexión desde el modal
  const handleTestConnection = async (testId: string): Promise<boolean> => {
    setIsTestingConfig(true);
    try {
      const meta = await fetchSpreadsheetMetadata(testId, token);
      if (meta && meta.tabs.length > 0) {
        setAvailableTabs(meta.tabs);
        setSpreadsheetTitle(meta.title);
      }
      return true;
    } catch (e) {
      console.error(e);
      return false;
    } finally {
      setIsTestingConfig(false);
    }
  };

  // 8. Guardar nueva configuración de hoja
  const handleSaveConfig = (newId: string, newTab: string) => {
    setSpreadsheetId(newId);
    setTabTitle(newTab);
    localStorage.setItem(STORAGE_KEY_SHEET_ID, newId);
    localStorage.setItem(STORAGE_KEY_TAB_TITLE, newTab);
    loadData(newId, newTab, token);
  };

  // 9. Filtrado de registros en memoria
  const filteredRecords = useMemo(() => {
    if (!dataset || !dataset.records) return [];

    const advisorCol = dataset.columns.find((c) => c.isAdvisor);
    const categoryCol = dataset.columns.find((c) => c.isCategory);
    const dateCol = dataset.columns.find((c) => c.isDate);

    return dataset.records.filter((rec) => {
      // Filtro Asesor
      if (selectedAdvisor && advisorCol) {
        if (String(rec[advisorCol.header] || '').trim() !== selectedAdvisor) {
          return false;
        }
      }

      // Filtro Categoría
      if (selectedCategory && categoryCol) {
        if (String(rec[categoryCol.header] || '').trim() !== selectedCategory) {
          return false;
        }
      }

      // Filtro Fecha Desde
      if (startDate && dateCol) {
        const val = String(rec[dateCol.header] || '');
        if (val < startDate) return false;
      }

      // Filtro Fecha Hasta
      if (endDate && dateCol) {
        const val = String(rec[dateCol.header] || '');
        if (val > endDate) return false;
      }

      return true;
    });
  }, [dataset, selectedAdvisor, selectedCategory, startDate, endDate]);

  // 10. Recalcular KPIs dinámicos al aplicar filtros
  const filteredKpis = useMemo(() => {
    if (!dataset) return [];
    if (dataset.isKpiSummaryTable || filteredRecords.length === dataset.records.length) {
      return dataset.kpis;
    }

    // Si los registros están filtrados, recalcular KPI en base a filteredRecords
    const numericCols = dataset.columns.filter((c) => (c.type === 'numeric' || c.type === 'percentage') && !c.isMeta);
    const metaCols = dataset.columns.filter((c) => c.isMeta);

    return numericCols.map((col, idx) => {
      const pairedMeta =
        metaCols.find((m) => m.header.toLowerCase().includes(col.header.toLowerCase())) ||
        (metaCols.length === 1 ? metaCols[0] : null);

      const vals = filteredRecords
        .map((r) => r[col.header])
        .filter((v) => typeof v === 'number' && !isNaN(v)) as number[];

      const metas = pairedMeta
        ? (filteredRecords
            .map((r) => r[pairedMeta.header])
            .filter((v) => typeof v === 'number' && !isNaN(v)) as number[])
        : [];

      if (vals.length === 0) {
        return {
          id: `kpi-filtered-${idx}`,
          name: col.header,
          actual: 0,
          meta: null,
          complianceRate: null,
          gap: null,
          pending: null,
          previousValue: null,
          absoluteChange: null,
          percentageChange: null,
          hasSufficientData: false,
          isPercentage: col.type === 'percentage',
          isCurrency: col.type === 'currency',
          recordCount: 0,
        };
      }

      const isRate =
        col.type === 'percentage' ||
        ['tasa', '%', 'promedio', 'ratio', 'cumplimiento'].some((k) => col.header.toLowerCase().includes(k));

      const actual = isRate ? vals.reduce((a, b) => a + b, 0) / vals.length : vals.reduce((a, b) => a + b, 0);

      let meta: number | null = null;
      if (metas.length > 0) {
        meta = isRate ? metas.reduce((a, b) => a + b, 0) / metas.length : metas.reduce((a, b) => a + b, 0);
      }

      let complianceRate: number | null = null;
      let gap: number | null = null;
      let pending: number | null = null;

      if (meta !== null && meta > 0) {
        complianceRate = (actual / meta) * 100;
        gap = actual - meta;
        pending = Math.max(0, meta - actual);
      }

      return {
        id: `kpi-filtered-${idx}`,
        name: col.header,
        actual,
        meta,
        complianceRate,
        gap,
        pending,
        previousValue: null,
        absoluteChange: null,
        percentageChange: null,
        hasSufficientData: true,
        isPercentage: col.type === 'percentage',
        isCurrency: col.type === 'currency',
        recordCount: vals.length,
      };
    });
  }, [dataset, filteredRecords]);

  // Limpiar filtros
  const handleResetFilters = () => {
    setSelectedAdvisor('');
    setSelectedCategory('');
    setStartDate('');
    setEndDate('');
  };

  // Determinar si la hoja está realmente vacía vs error
  const isSheetEmpty =
    connectionStatus === 'connected' &&
    (!dataset || dataset.records.length === 0 || rawRows.length === 0);

  const hasData = dataset && dataset.records.length > 0 && rawRows.length > 0;

  return (
    <div className="min-h-screen bg-[#F8F9FA] text-[#171717] flex flex-col font-sans selection:bg-[#FFF4CC] selection:text-[#171717]">
      {/* Encabezado Corporativo Oficial */}
      <Header
        status={connectionStatus}
        statusMessage={statusMessage}
        lastUpdated={lastUpdated}
        isUpdating={isUpdating}
        onRefresh={() => loadData(spreadsheetId, tabTitle, token)}
        user={user}
        onSignIn={handleSignIn}
        onSignOut={handleSignOut}
        onOpenSheetConfig={() => setIsConfigModalOpen(true)}
        spreadsheetTitle={spreadsheetTitle}
        spreadsheetId={spreadsheetId}
      />

      {/* Barra Informativa de Origen Activo */}
      <div className="bg-white border-b border-[#E5E7EB] py-2 px-4 sm:px-6 lg:px-8 text-xs text-[#4B5563]">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Database className="w-3.5 h-3.5 text-[#F5C518]" />
            <span>
              Origen oficial:{' '}
              <strong className="text-[#171717]">
                {spreadsheetTitle || (spreadsheetId ? `Hoja (${spreadsheetId.slice(0, 10)}...)` : 'Sin configurar')}
              </strong>
            </span>
            {tabTitle && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded bg-[#F8F9FA] border border-[#E5E7EB] text-[#171717] font-medium">
                Pestaña: {tabTitle}
              </span>
            )}
          </div>

          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1 text-[11px] text-[#16A34A] font-medium">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Modo seguro: Solo Lectura</span>
            </span>
            <span className="text-[11px] text-[#4B5563] hidden sm:inline">
              Actualización periódica cada 30s
            </span>
          </div>
        </div>
      </div>

      {/* Contenido Principal */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-6 sm:space-y-8">
        {/* Caso 1: Error de Conexión o Sin Configurar */}
        {connectionStatus === 'error' && !hasData && (
          <ConnectionErrorState
            errorMessage={statusMessage || 'No se pudo conectar a la hoja de Google Sheets'}
            onRetry={() => loadData(spreadsheetId, tabTitle, token)}
            onOpenConfig={() => setIsConfigModalOpen(true)}
            onSignIn={handleSignIn}
            isSignedIn={Boolean(user)}
            isRetrying={isUpdating}
          />
        )}

        {/* Caso 2: Hoja Realmente Vacía (Requisito Obligatorio Sección 11) */}
        {isSheetEmpty && (
          <EmptyState
            onRefresh={() => loadData(spreadsheetId, tabTitle, token)}
            isUpdating={isUpdating}
            spreadsheetId={spreadsheetId}
          />
        )}

        {/* Caso 3: Datos Reales Conectados y Listos */}
        {hasData && dataset && (
          <div className="space-y-8">
            {/* Barra de Filtros Dinámicos */}
            <FilterBar
              columns={dataset.columns}
              availableAdvisors={dataset.availableAdvisors}
              availableCategories={dataset.availableCategories}
              selectedAdvisor={selectedAdvisor}
              onSelectAdvisor={setSelectedAdvisor}
              selectedCategory={selectedCategory}
              onSelectCategory={setSelectedCategory}
              startDate={startDate}
              onStartDateChange={setStartDate}
              endDate={endDate}
              onEndDateChange={setEndDate}
              onResetFilters={handleResetFilters}
              totalRecords={dataset.records.length}
              filteredCount={filteredRecords.length}
            />

            {/* SECCIÓN 1: Tarjetas KPI (Indicadores Principales) */}
            <section className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 bg-[#F5C518] rounded-xs inline-block"></span>
                  <h2 className="text-base sm:text-lg font-bold text-[#171717] tracking-tight">
                    Resumen Ejecutivo de Indicadores
                  </h2>
                </div>
                <span className="text-xs text-[#4B5563]">
                  {filteredKpis.length} indicadores calculados
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
                {filteredKpis.map((kpi, index) => (
                  <KpiCard
                    key={kpi.id}
                    kpi={kpi}
                    isPrimary={index === 0} // Resaltar el primer indicador con acento dorado
                  />
                ))}
              </div>
            </section>

            {/* SECCIÓN 2: Gráficos y Visualizaciones */}
            <section className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <BarChart className="w-4 h-4 text-[#F5C518]" />
                  <h2 className="text-base sm:text-lg font-bold text-[#171717] tracking-tight">
                    Análisis Visual y Comparativo
                  </h2>
                </div>
                <span className="text-xs text-[#4B5563]">
                  Basado en registros reales de Mall Ibagué
                </span>
              </div>

              <ChartsSection dataset={dataset} filteredRecords={filteredRecords} />
            </section>

            {/* SECCIÓN 3: Tabla Detallada de Registros */}
            <section className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Layers className="w-4 h-4 text-[#F5C518]" />
                  <h2 className="text-base sm:text-lg font-bold text-[#171717] tracking-tight">
                    Detalle de Registros
                  </h2>
                </div>
                <span className="text-xs text-[#4B5563]">
                  {filteredRecords.length} registros en consulta
                </span>
              </div>

              <DataTable
                headers={rawHeaders}
                columns={dataset.columns}
                records={filteredRecords}
                tableName={`Registros: ${tabTitle}`}
              />
            </section>
          </div>
        )}
      </main>

      {/* Pie de Página Corporativo */}
      <footer className="bg-white border-t border-[#E5E7EB] py-4 text-xs text-[#4B5563] mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-[#171717]">
              Uso de herramienta pospagos PLUS - Mall Ibagué
            </span>
            <span>•</span>
            <span>Punto de Venta Mall Ibagué</span>
          </div>
          <div className="flex items-center gap-4 text-[11px]">
            <span>Lectura directa de Google Sheets</span>
            <span>•</span>
            <span>Cálculos ejecutados en el cliente</span>
          </div>
        </div>
      </footer>

      {/* Modal de Configuración de Google Sheets */}
      <SheetConfigModal
        isOpen={isConfigModalOpen}
        onClose={() => setIsConfigModalOpen(false)}
        spreadsheetId={spreadsheetId}
        tabTitle={tabTitle}
        tabs={availableTabs}
        onSave={handleSaveConfig}
        isTesting={isTestingConfig}
        onTestConnection={handleTestConnection}
      />
    </div>
  );
}
