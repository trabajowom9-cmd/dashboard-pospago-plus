/**
 * Servicio para consulta de Google Sheets (Solo Lectura)
 */

export interface SheetTab {
  id: number;
  title: string;
  rowCount?: number;
  columnCount?: number;
}

export interface SpreadsheetMetadata {
  id: string;
  title: string;
  tabs: SheetTab[];
}

export interface SheetDataResult {
  headers: string[];
  rows: (string | number | boolean | null)[][];
  totalRows: number;
  tabTitle: string;
  spreadsheetTitle: string;
}

/**
 * Extrae el ID de una URL de Google Sheets o devuelve el ID limpio
 */
export function extractSpreadsheetId(input: string): string {
  if (!input) return '';
  const trimmed = input.trim();
  
  // Buscar patrón de URL: /spreadsheets/d/([a-zA-Z0-9-_]+)
  const urlMatch = trimmed.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
  if (urlMatch && urlMatch[1]) {
    return urlMatch[1];
  }
  
  // Si ya es un ID (alfanumérico con guiones)
  if (/^[a-zA-Z0-9-_]{20,}$/.test(trimmed)) {
    return trimmed;
  }
  
  return trimmed;
}

/**
 * Obtiene los metadatos de la hoja de cálculo (título y pestañas)
 */
export async function fetchSpreadsheetMetadata(
  spreadsheetId: string,
  accessToken?: string | null
): Promise<SpreadsheetMetadata> {
  const cleanId = extractSpreadsheetId(spreadsheetId);
  if (!cleanId) {
    throw new Error('ID de Google Sheets inválido o vacío');
  }

  // 1. Si tenemos token de OAuth, usamos la API oficial de Google Sheets v4
  if (accessToken) {
    const response = await fetch(
      `https://sheets.googleapis.com/v4/spreadsheets/${cleanId}?fields=properties.title,sheets.properties`,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      }
    );

    if (!response.ok) {
      if (response.status === 401) {
        throw new Error('Tu sesión ha expirado o requiere autorización nuevamente.');
      }
      if (response.status === 403) {
        throw new Error('No tienes permisos de acceso a este archivo de Google Sheets. Asegúrate de que tu cuenta tenga acceso de lectura.');
      }
      if (response.status === 404) {
        throw new Error('Hoja de cálculo no encontrada. Verifica que el ID o enlace sea correcto.');
      }
      const errJson = await response.json().catch(() => null);
      throw new Error(errJson?.error?.message || `Error al conectar con Google Sheets (${response.status})`);
    }

    const data = await response.json();
    const tabs: SheetTab[] = (data.sheets || []).map((s: any) => ({
      id: s.properties?.sheetId || 0,
      title: s.properties?.title || 'Hoja1',
      rowCount: s.properties?.gridProperties?.rowCount,
      columnCount: s.properties?.gridProperties?.columnCount,
    }));

    return {
      id: cleanId,
      title: data.properties?.title || 'Hoja de cálculo',
      tabs,
    };
  }

  // 2. Si no hay token, intentar verificar acceso público mediante GViz
  const publicTestUrl = `https://docs.google.com/spreadsheets/d/${cleanId}/gviz/tq?tqx=out:json`;
  const res = await fetch(publicTestUrl);
  if (!res.ok) {
    throw new Error('No se pudo acceder a la hoja. Inicia sesión con Google para acceder a hojas privadas.');
  }

  const text = await res.text();
  if (text.includes('google.visualization.Query.setResponse')) {
    return {
      id: cleanId,
      title: 'Hoja de cálculo conectada',
      tabs: [{ id: 0, title: 'Hoja 1' }],
    };
  }

  throw new Error('Autenticación requerida. Por favor inicia sesión con Google.');
}

/**
 * Obtiene los datos de una pestaña específica de la hoja de cálculo
 */
export async function fetchSheetData(
  spreadsheetId: string,
  tabTitle: string,
  accessToken?: string | null
): Promise<SheetDataResult> {
  const cleanId = extractSpreadsheetId(spreadsheetId);
  if (!cleanId) {
    throw new Error('ID de Google Sheets inválido');
  }

  // A. Con token OAuth (Google Sheets API v4)
  if (accessToken) {
    const range = encodeURIComponent(`'${tabTitle}'!A1:ZZ`);
    const url = `https://sheets.googleapis.com/v4/spreadsheets/${cleanId}/values/${range}?valueRenderOption=FORMATTED_VALUE`;
    
    const response = await fetch(url, {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });

    if (!response.ok) {
      if (response.status === 401) {
        throw new Error('Sesión expirada. Por favor vuelve a iniciar sesión con Google.');
      }
      if (response.status === 403) {
        throw new Error('Permiso denegado para consultar la hoja en Google Sheets.');
      }
      if (response.status === 404) {
        throw new Error('No se encontró la pestaña o el archivo especificado.');
      }
      const err = await response.json().catch(() => null);
      throw new Error(err?.error?.message || `Error al leer datos (${response.status})`);
    }

    const data = await response.json();
    const rawValues: any[][] = data.values || [];

    if (rawValues.length === 0) {
      return {
        headers: [],
        rows: [],
        totalRows: 0,
        tabTitle,
        spreadsheetTitle: cleanId,
      };
    }

    const headers = rawValues[0].map((h: any) => String(h || '').trim());
    const rows = rawValues.slice(1).filter((r: any[]) => {
      // Filtrar filas completamente vacías
      return r.some((cell) => cell !== undefined && cell !== null && String(cell).trim() !== '');
    });

    return {
      headers,
      rows,
      totalRows: rows.length,
      tabTitle,
      spreadsheetTitle: cleanId,
    };
  }

  // B. Sin token (hojas públicas vía GViz CSV / JSON)
  const gvizUrl = `https://docs.google.com/spreadsheets/d/${cleanId}/gviz/tq?tqx=out:csv&sheet=${encodeURIComponent(
    tabTitle
  )}`;
  
  const response = await fetch(gvizUrl);
  if (!response.ok) {
    throw new Error('No se pudo acceder a la hoja sin autenticación. Inicia sesión con tu cuenta de Google.');
  }

  const csvText = await response.text();
  const parsedRows = parseCSV(csvText);

  if (parsedRows.length === 0) {
    return {
      headers: [],
      rows: [],
      totalRows: 0,
      tabTitle,
      spreadsheetTitle: cleanId,
    };
  }

  const headers = parsedRows[0].map((h) => String(h).trim());
  const rows = parsedRows.slice(1).filter((r) => r.some((c) => String(c).trim() !== ''));

  return {
    headers,
    rows,
    totalRows: rows.length,
    tabTitle,
    spreadsheetTitle: cleanId,
  };
}

/**
 * Parser CSV robusto para Google Sheets GViz output
 */
function parseCSV(text: string): string[][] {
  const lines: string[][] = [];
  let row: string[] = [];
  let insideQuotes = false;
  let currentField = '';

  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    const nextChar = text[i + 1];

    if (char === '"') {
      if (insideQuotes && nextChar === '"') {
        currentField += '"';
        i++;
      } else {
        insideQuotes = !insideQuotes;
      }
    } else if (char === ',' && !insideQuotes) {
      row.push(currentField);
      currentField = '';
    } else if ((char === '\r' || char === '\n') && !insideQuotes) {
      if (char === '\r' && nextChar === '\n') {
        i++;
      }
      row.push(currentField);
      lines.push(row);
      row = [];
      currentField = '';
    } else {
      currentField += char;
    }
  }

  if (currentField.length > 0 || row.length > 0) {
    row.push(currentField);
    lines.push(row);
  }

  return lines;
}
