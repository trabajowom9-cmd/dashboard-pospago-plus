/**
 * Utilidades para análisis y cálculo de indicadores de Google Sheets
 */

export interface ParsedColumn {
  index: number;
  header: string;
  type: 'numeric' | 'date' | 'category' | 'percentage' | 'currency';
  isMeta: boolean;
  isAdvisor: boolean;
  isDate: boolean;
  isCategory: boolean;
}

export interface KpiItem {
  id: string;
  name: string;
  actual: number;
  meta: number | null;
  unit?: string;
  complianceRate: number | null; // % cumplimiento
  gap: number | null; // brecha (actual - meta)
  pending: number | null; // pendiente: max(0, meta - actual)
  previousValue: number | null;
  absoluteChange: number | null;
  percentageChange: number | null;
  hasSufficientData: boolean;
  isPercentage: boolean;
  isCurrency: boolean;
  recordCount: number;
}

export interface ChartDataSeries {
  label: string;
  value: number;
  secondaryValue?: number;
  target?: number;
  color?: string;
}

export interface ParsedDataset {
  isKpiSummaryTable: boolean; // Si la tabla es de tipo Indicador | Real | Meta
  columns: ParsedColumn[];
  dateColumnIndex: number;
  advisorColumnIndex: number;
  categoryColumnIndex: number;
  records: Record<string, any>[];
  kpis: KpiItem[];
  availableAdvisors: string[];
  availableCategories: string[];
  dateRange: { min: string; max: string } | null;
}

/**
 * Limpia y convierte texto en número si es válido
 */
export function parseNumberValue(val: any): number | null {
  if (val === null || val === undefined) return null;
  if (typeof val === 'number') {
    return isNaN(val) ? null : val;
  }

  const str = String(val).trim();
  if (str === '' || str === '-' || str === 'N/A' || str === 'n/a') return null;

  // Remover signos de moneda y espacios
  let clean = str.replace(/[$€COP\s]/g, '');

  // Detectar porcentajes
  const isPercent = clean.includes('%');
  clean = clean.replace(/%/g, '');

  // Manejo de separadores decimales y miles (formato latino vs anglosajón)
  // Ej: 1.250,50 o 1,250.50 o 1250,5
  if (clean.includes(',') && clean.includes('.')) {
    if (clean.lastIndexOf(',') > clean.lastIndexOf('.')) {
      // 1.250,50 -> 1250.50
      clean = clean.replace(/\./g, '').replace(',', '.');
    } else {
      // 1,250.50 -> 1250.50
      clean = clean.replace(/,/g, '');
    }
  } else if (clean.includes(',')) {
    // Si solo tiene coma y 1 o 2 dígitos después, es decimal
    const parts = clean.split(',');
    if (parts.length === 2 && parts[1].length <= 2) {
      clean = clean.replace(',', '.');
    } else {
      // Es separador de miles
      clean = clean.replace(/,/g, '');
    }
  }

  const num = parseFloat(clean);
  if (isNaN(num)) return null;

  // Si era porcentaje y venía como 85%, para cálculos matemáticos se conserva el número 85
  return num;
}

/**
 * Detecta si una cadena representa una fecha
 */
export function isDateString(val: any): boolean {
  if (!val) return false;
  const str = String(val).trim();
  // Formatos habituales: YYYY-MM-DD, DD/MM/YYYY, DD-MM-YYYY, etc.
  if (/^\d{4}[-/.]\d{1,2}[-/.]\d{1,2}/.test(str)) return true;
  if (/^\d{1,2}[-/.]\d{1,2}[-/.]\d{2,4}/.test(str)) return true;
  const parsed = Date.parse(str);
  return !isNaN(parsed) && isNaN(Number(str));
}

/**
 * Formatea un número en formato local profesional
 */
export function formatNumber(val: number | null | undefined, decimals = 0): string {
  if (val === null || val === undefined || isNaN(val)) return 'Sin datos suficientes';
  return new Intl.NumberFormat('es-CO', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(val);
}

/**
 * Formatea porcentaje
 */
export function formatPercent(val: number | null | undefined): string {
  if (val === null || val === undefined || isNaN(val)) return 'Sin datos suficientes';
  return `${new Intl.NumberFormat('es-CO', {
    minimumFractionDigits: 1,
    maximumFractionDigits: 1,
  }).format(val)}%`;
}

/**
 * Analiza el conjunto de encabezados y filas de Google Sheets
 */
export function parseSheetData(headers: string[], rows: (string | number | boolean | null)[][]): ParsedDataset {
  if (!headers || headers.length === 0 || !rows || rows.length === 0) {
    return {
      isKpiSummaryTable: false,
      columns: [],
      dateColumnIndex: -1,
      advisorColumnIndex: -1,
      categoryColumnIndex: -1,
      records: [],
      kpis: [],
      availableAdvisors: [],
      availableCategories: [],
      dateRange: null,
    };
  }

  // 1. Verificar si la hoja es de estructura Resumen de Indicadores:
  // e.g. Encabezado con "Indicador" / "Metrica" y columnas como "Real" / "Actual" y "Meta"
  const lowerHeaders = headers.map((h) => h.toLowerCase().trim());
  const indicatorColIdx = lowerHeaders.findIndex((h) =>
    ['indicador', 'métrica', 'metrica', 'concepto', 'kpi', 'item', 'nombre'].some((k) => h.includes(k))
  );
  const actualColIdx = lowerHeaders.findIndex((h) =>
    ['real', 'actual', 'ejecutado', 'resultado', 'alcanzado', 'valor', 'total'].some((k) => h.includes(k))
  );
  const metaColIdx = lowerHeaders.findIndex((h) =>
    ['meta', 'objetivo', 'target', 'presupuesto', 'cuota'].some((k) => h.includes(k))
  );

  const isKpiSummary = indicatorColIdx !== -1 && actualColIdx !== -1;

  if (isKpiSummary) {
    // Modo resumen de indicadores en filas
    const kpis: KpiItem[] = [];
    rows.forEach((row, idx) => {
      const name = String(row[indicatorColIdx] || '').trim();
      if (!name) return;

      const actualNum = parseNumberValue(row[actualColIdx]);
      if (actualNum === null) return;

      const metaNum = metaColIdx !== -1 ? parseNumberValue(row[metaColIdx]) : null;
      const isPercent = name.toLowerCase().includes('%') || name.toLowerCase().includes('porcentaje') || name.toLowerCase().includes('tasa');

      let complianceRate: number | null = null;
      let gap: number | null = null;
      let pending: number | null = null;

      if (metaNum !== null && metaNum > 0) {
        complianceRate = (actualNum / metaNum) * 100;
        gap = actualNum - metaNum;
        pending = Math.max(0, metaNum - actualNum);
      }

      kpis.push({
        id: `kpi-summary-${idx}`,
        name,
        actual: actualNum,
        meta: metaNum,
        complianceRate,
        gap,
        pending,
        previousValue: null,
        absoluteChange: null,
        percentageChange: null,
        hasSufficientData: true,
        isPercentage: isPercent,
        isCurrency: name.toLowerCase().includes('$') || name.toLowerCase().includes('ingreso') || name.toLowerCase().includes('venta'),
        recordCount: 1,
      });
    });

    return {
      isKpiSummaryTable: true,
      columns: headers.map((h, i) => ({
        index: i,
        header: h,
        type: i === actualColIdx || i === metaColIdx ? 'numeric' : 'category',
        isMeta: i === metaColIdx,
        isAdvisor: false,
        isDate: false,
        isCategory: i === indicatorColIdx,
      })),
      dateColumnIndex: -1,
      advisorColumnIndex: -1,
      categoryColumnIndex: indicatorColIdx,
      records: rows.map((r) => {
        const obj: Record<string, any> = {};
        headers.forEach((h, i) => {
          obj[h] = r[i];
        });
        return obj;
      }),
      kpis,
      availableAdvisors: [],
      availableCategories: [],
      dateRange: null,
    };
  }

  // 2. Modo tabular estándar (Registros por fecha / asesor / transacciones / métricas)
  const columns: ParsedColumn[] = headers.map((header, index) => {
    const lower = header.toLowerCase();

    // Muestrear valores de la columna para inferir tipo real
    const sampleVals = rows.slice(0, 30).map((r) => r[index]);
    const validNumCount = sampleVals.filter((v) => parseNumberValue(v) !== null).length;
    const validDateCount = sampleVals.filter((v) => isDateString(v)).length;

    const isDate =
      ['fecha', 'date', 'dia', 'día', 'mes', 'semana', 'periodo'].some((k) => lower.includes(k)) ||
      validDateCount > sampleVals.length * 0.6;

    const isAdvisor =
      ['asesor', 'responsable', 'ejecutivo', 'promotor', 'agente', 'colaborador', 'usuario', 'vendedor'].some((k) =>
        lower.includes(k)
      );

    const isCategory =
      ['categoria', 'categoría', 'canal', 'tipo', 'segmento', 'plan', 'herramienta', 'pospago'].some((k) =>
        lower.includes(k)
      ) && !isAdvisor && !isDate;

    const isMeta = ['meta', 'objetivo', 'target', 'cuota', 'presupuesto'].some((k) => lower.includes(k));

    const isNumeric = validNumCount > sampleVals.length * 0.5 && !isDate;
    const isPercentage = lower.includes('%') || lower.includes('porcentaje') || lower.includes('tasa');
    const isCurrency = lower.includes('$') || lower.includes('monto') || lower.includes('valor');

    let type: ParsedColumn['type'] = 'category';
    if (isDate) type = 'date';
    else if (isPercentage) type = 'percentage';
    else if (isCurrency) type = 'currency';
    else if (isNumeric) type = 'numeric';

    return {
      index,
      header,
      type,
      isMeta,
      isAdvisor,
      isDate,
      isCategory,
    };
  });

  const dateCol = columns.find((c) => c.isDate);
  const advisorCol = columns.find((c) => c.isAdvisor);
  const categoryCol = columns.find((c) => c.isCategory);

  const dateColumnIndex = dateCol ? dateCol.index : -1;
  const advisorColumnIndex = advisorCol ? advisorCol.index : -1;
  const categoryColumnIndex = categoryCol ? categoryCol.index : -1;

  // Convertir filas en registros limpios
  const records: Record<string, any>[] = rows.map((row, rowIdx) => {
    const record: Record<string, any> = { _id: rowIdx };
    columns.forEach((col) => {
      const rawVal = row[col.index];
      if (col.type === 'numeric' || col.type === 'percentage' || col.type === 'currency' || col.isMeta) {
        record[col.header] = parseNumberValue(rawVal);
      } else {
        record[col.header] = rawVal !== undefined && rawVal !== null ? String(rawVal).trim() : '';
      }
    });
    return record;
  });

  // Extraer valores únicos para filtros
  const advisorsSet = new Set<string>();
  const categoriesSet = new Set<string>();
  const dates: string[] = [];

  records.forEach((rec) => {
    if (advisorCol) {
      const val = rec[advisorCol.header];
      if (val && String(val).trim()) advisorsSet.add(String(val).trim());
    }
    if (categoryCol) {
      const val = rec[categoryCol.header];
      if (val && String(val).trim()) categoriesSet.add(String(val).trim());
    }
    if (dateCol) {
      const val = rec[dateCol.header];
      if (val && String(val).trim()) dates.push(String(val).trim());
    }
  });

  // Identificar columnas numéricas para KPI
  const numericCols = columns.filter((c) => (c.type === 'numeric' || c.type === 'percentage' || c.type === 'currency') && !c.isMeta);
  const metaCols = columns.filter((c) => c.isMeta);

  const kpis: KpiItem[] = [];

  numericCols.forEach((numCol) => {
    // Intentar emparejar con columna de meta correspondiente si existe
    // Por ejemplo: 'Pospagos' empareja con 'Meta Pospagos' o 'Meta'
    const pairedMetaCol =
      metaCols.find((m) => m.header.toLowerCase().includes(numCol.header.toLowerCase())) ||
      (metaCols.length === 1 ? metaCols[0] : null);

    const validValues: number[] = [];
    const validMetas: number[] = [];

    records.forEach((rec) => {
      const val = rec[numCol.header];
      if (typeof val === 'number' && !isNaN(val)) {
        validValues.push(val);
      }
      if (pairedMetaCol) {
        const metaVal = rec[pairedMetaCol.header];
        if (typeof metaVal === 'number' && !isNaN(metaVal)) {
          validMetas.push(metaVal);
        }
      }
    });

    if (validValues.length === 0) {
      kpis.push({
        id: `kpi-${numCol.index}`,
        name: numCol.header,
        actual: 0,
        meta: null,
        complianceRate: null,
        gap: null,
        pending: null,
        previousValue: null,
        absoluteChange: null,
        percentageChange: null,
        hasSufficientData: false,
        isPercentage: numCol.type === 'percentage',
        isCurrency: numCol.type === 'currency',
        recordCount: 0,
      });
      return;
    }

    // Si es porcentaje o promedio, calculamos el promedio. Si son cantidades acumuladas, sumamos.
    const isAverageOrRate =
      numCol.type === 'percentage' ||
      ['tasa', '%', 'promedio', 'ratio', 'adopcion', 'adopción', 'cumplimiento'].some((k) =>
        numCol.header.toLowerCase().includes(k)
      );

    const actualTotal = isAverageOrRate
      ? validValues.reduce((a, b) => a + b, 0) / validValues.length
      : validValues.reduce((a, b) => a + b, 0);

    let metaTotal: number | null = null;
    if (validMetas.length > 0) {
      metaTotal = isAverageOrRate
        ? validMetas.reduce((a, b) => a + b, 0) / validMetas.length
        : validMetas.reduce((a, b) => a + b, 0);
    }

    let complianceRate: number | null = null;
    let gap: number | null = null;
    let pending: number | null = null;

    if (metaTotal !== null && metaTotal > 0) {
      complianceRate = (actualTotal / metaTotal) * 100;
      gap = actualTotal - metaTotal;
      pending = Math.max(0, metaTotal - actualTotal);
    }

    // Variación histórica si hay fechas
    let previousValue: number | null = null;
    let absoluteChange: number | null = null;
    let percentageChange: number | null = null;

    if (dateCol && records.length >= 2) {
      // Tomar mitad anterior vs mitad actual o último periodo vs periodo previo
      const half = Math.floor(records.length / 2);
      const prevSlice = records.slice(0, half);
      const currSlice = records.slice(half);

      const prevVals = prevSlice.map((r) => r[numCol.header]).filter((v) => typeof v === 'number');
      const currVals = currSlice.map((r) => r[numCol.header]).filter((v) => typeof v === 'number');

      if (prevVals.length > 0 && currVals.length > 0) {
        const prevTotal = isAverageOrRate
          ? prevVals.reduce((a, b) => a + b, 0) / prevVals.length
          : prevVals.reduce((a, b) => a + b, 0);
        const currTotal = isAverageOrRate
          ? currVals.reduce((a, b) => a + b, 0) / currVals.length
          : currVals.reduce((a, b) => a + b, 0);

        previousValue = prevTotal;
        absoluteChange = currTotal - prevTotal;
        if (prevTotal !== 0) {
          percentageChange = ((currTotal - prevTotal) / Math.abs(prevTotal)) * 100;
        }
      }
    }

    kpis.push({
      id: `kpi-${numCol.index}`,
      name: numCol.header,
      actual: actualTotal,
      meta: metaTotal,
      complianceRate,
      gap,
      pending,
      previousValue,
      absoluteChange,
      percentageChange,
      hasSufficientData: true,
      isPercentage: numCol.type === 'percentage',
      isCurrency: numCol.type === 'currency',
      recordCount: validValues.length,
    });
  });

  return {
    isKpiSummaryTable: false,
    columns,
    dateColumnIndex,
    advisorColumnIndex,
    categoryColumnIndex,
    records,
    kpis,
    availableAdvisors: Array.from(advisorsSet).sort(),
    availableCategories: Array.from(categoriesSet).sort(),
    dateRange: dates.length > 0 ? { min: dates[0], max: dates[dates.length - 1] } : null,
  };
}
