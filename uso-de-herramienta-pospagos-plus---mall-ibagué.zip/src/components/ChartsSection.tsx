import React, { useState } from 'react';
import { BarChart3, TrendingUp, PieChart, Target, Info } from 'lucide-react';
import { ParsedDataset, formatNumber, formatPercent } from '../utils/dataParser';

interface ChartsSectionProps {
  dataset: ParsedDataset;
  filteredRecords: Record<string, any>[];
}

export const ChartsSection: React.FC<ChartsSectionProps> = ({ dataset, filteredRecords }) => {
  const [activeTooltip, setActiveTooltip] = useState<{
    x: number;
    y: number;
    title: string;
    value: string;
  } | null>(null);

  const { columns, dateColumnIndex, advisorColumnIndex, categoryColumnIndex, isKpiSummaryTable, kpis } =
    dataset;

  // Si no hay registros o columnas
  if (!filteredRecords || filteredRecords.length === 0) {
    return (
      <div className="bg-white rounded-xl p-8 border border-[#E5E7EB] text-center text-[#4B5563]">
        <Info className="w-8 h-8 mx-auto mb-2 text-[#F5C518]" />
        <p className="text-sm font-medium">Sin datos suficientes para generar visualizaciones</p>
      </div>
    );
  }

  // Identificar columnas para gráficos
  const advisorCol = columns.find((c) => c.isAdvisor);
  const categoryCol = columns.find((c) => c.isCategory);
  const dateCol = columns.find((c) => c.isDate);
  const numericCols = columns.filter((c) => (c.type === 'numeric' || c.type === 'percentage') && !c.isMeta);
  const mainNumericCol = numericCols[0] || null;

  // 1. Gráfico 1: Comparativa Real vs Meta (si existen metas)
  const kpisWithMeta = kpis.filter((k) => k.meta !== null && k.hasSufficientData);

  // 2. Gráfico 2: Desglose por Asesor / Responsable
  let advisorData: { label: string; value: number }[] = [];
  if (advisorCol && mainNumericCol) {
    const map: Record<string, number> = {};
    filteredRecords.forEach((r) => {
      const adv = String(r[advisorCol.header] || 'Sin asignar').trim();
      const val = Number(r[mainNumericCol.header]) || 0;
      map[adv] = (map[adv] || 0) + val;
    });

    advisorData = Object.entries(map)
      .map(([label, value]) => ({ label, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 8); // Top 8 asesores
  }

  // 3. Gráfico 3: Tendencia Temporal (si hay columna de fechas)
  let timeData: { date: string; value: number }[] = [];
  if (dateCol && mainNumericCol) {
    const map: Record<string, number> = {};
    filteredRecords.forEach((r) => {
      const dt = String(r[dateCol.header] || '').trim();
      if (!dt) return;
      const val = Number(r[mainNumericCol.header]) || 0;
      map[dt] = (map[dt] || 0) + val;
    });

    timeData = Object.entries(map)
      .map(([date, value]) => ({ date, value }))
      .slice(0, 15); // Máximo 15 periodos para legibilidad
  }

  // 4. Gráfico 4: Distribución por Categoría o Tipo (Donut)
  let distributionData: { label: string; value: number; percent: number }[] = [];
  const groupCol = categoryCol || (advisorCol && advisorData.length <= 5 ? advisorCol : null);
  if (groupCol && mainNumericCol) {
    const map: Record<string, number> = {};
    let total = 0;
    filteredRecords.forEach((r) => {
      const cat = String(r[groupCol.header] || 'General').trim();
      const val = Number(r[mainNumericCol.header]) || 0;
      map[cat] = (map[cat] || 0) + val;
      total += val;
    });

    if (total > 0) {
      distributionData = Object.entries(map)
        .map(([label, value]) => ({
          label,
          value,
          percent: (value / total) * 100,
        }))
        .sort((a, b) => b.value - a.value)
        .slice(0, 6);
    }
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* GRÁFICO A: Comparativa Resultado vs Meta */}
        <div className="bg-white rounded-xl p-6 border border-[#E5E7EB] shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between pb-4 border-b border-[#E5E7EB]">
            <div className="flex items-center gap-2">
              <Target className="w-5 h-5 text-[#F5C518]" />
              <h3 className="text-sm font-bold text-[#171717]">
                {kpisWithMeta.length > 0 ? 'Resultado vs Meta Oficial' : 'Comparativa de Indicadores'}
              </h3>
            </div>
            <span className="text-xs text-[#4B5563]">Cifras consolidadas</span>
          </div>

          <div className="mt-6 space-y-5">
            {(kpisWithMeta.length > 0 ? kpisWithMeta.slice(0, 5) : kpis.slice(0, 5)).map((item) => {
              const maxVal = Math.max(item.actual, item.meta || 0, 1);
              const actualPct = (item.actual / maxVal) * 100;
              const metaPct = item.meta ? (item.meta / maxVal) * 100 : 0;

              return (
                <div key={item.id} className="space-y-1.5">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-[#171717]">{item.name}</span>
                    <div className="flex items-center gap-3">
                      <span className="font-bold text-[#171717]">
                        Real: {item.isPercentage ? formatPercent(item.actual) : formatNumber(item.actual, 0)}
                      </span>
                      {item.meta !== null && (
                        <span className="text-[#4B5563]">
                          Meta: {item.isPercentage ? formatPercent(item.meta) : formatNumber(item.meta, 0)}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Barras de comparación */}
                  <div className="space-y-1">
                    {/* Barra Real */}
                    <div className="h-3 w-full bg-[#F8F9FA] rounded-full overflow-hidden border border-[#E5E7EB]">
                      <div
                        className="h-full bg-[#F5C518] rounded-full transition-all duration-300"
                        style={{ width: `${Math.min(100, Math.max(0, actualPct))}%` }}
                        title={`Real: ${item.actual}`}
                      />
                    </div>

                    {/* Línea o Barra de Meta */}
                    {item.meta !== null && (
                      <div className="h-1.5 w-full bg-[#F8F9FA] rounded-full overflow-hidden">
                        <div
                          className="h-full bg-[#171717] rounded-full transition-all duration-300 opacity-60"
                          style={{ width: `${Math.min(100, Math.max(0, metaPct))}%` }}
                          title={`Meta: ${item.meta}`}
                        />
                      </div>
                    )}
                  </div>
                </div>
              );
            })}

            {kpis.length === 0 && (
              <p className="text-xs text-[#4B5563] text-center py-6">
                Sin datos suficientes en la hoja para graficar indicadores.
              </p>
            )}
          </div>

          <div className="mt-4 pt-3 border-t border-[#E5E7EB] flex items-center justify-between text-xs text-[#4B5563]">
            <div className="flex items-center gap-4">
              <span className="inline-flex items-center gap-1.5">
                <span className="w-3 h-3 rounded-sm bg-[#F5C518]"></span>
                <span>Resultado Real</span>
              </span>
              <span className="inline-flex items-center gap-1.5">
                <span className="w-3 h-1.5 rounded-sm bg-[#171717] opacity-60"></span>
                <span>Meta</span>
              </span>
            </div>
          </div>
        </div>

        {/* GRÁFICO B: Rendimiento por Asesor o Responsable */}
        <div className="bg-white rounded-xl p-6 border border-[#E5E7EB] shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between pb-4 border-b border-[#E5E7EB]">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-[#F5C518]" />
              <h3 className="text-sm font-bold text-[#171717]">
                {advisorCol ? `Rendimiento por ${advisorCol.header}` : 'Desglose por Categoría'}
              </h3>
            </div>
            <span className="text-xs text-[#4B5563]">
              {mainNumericCol ? mainNumericCol.header : 'Métrica principal'}
            </span>
          </div>

          <div className="mt-6">
            {advisorData.length > 0 ? (
              <div className="space-y-3">
                {(() => {
                  const maxAdvisorVal = Math.max(...advisorData.map((d) => d.value), 1);
                  return advisorData.map((item, idx) => {
                    const pct = (item.value / maxAdvisorVal) * 100;
                    return (
                      <div key={idx} className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="font-medium text-[#171717] truncate max-w-[200px]">
                            {item.label}
                          </span>
                          <span className="font-bold text-[#171717]">
                            {formatNumber(item.value, 0)}
                          </span>
                        </div>
                        <div className="h-3 w-full bg-[#F8F9FA] rounded-full overflow-hidden border border-[#E5E7EB]">
                          <div
                            className="h-full bg-[#F5C518] rounded-full transition-all duration-300"
                            style={{ width: `${Math.min(100, Math.max(3, pct))}%` }}
                          />
                        </div>
                      </div>
                    );
                  });
                })()}
              </div>
            ) : (
              <div className="py-12 text-center text-xs text-[#4B5563] space-y-1">
                <Info className="w-6 h-6 mx-auto text-[#4B5563]/40" />
                <p>No se identificó columna de Asesores o Responsables en esta pestaña.</p>
                <p className="text-[11px] text-[#4B5563]/70">
                  Agrega una columna con encabezado "Asesor" o "Responsable" para habilitar esta comparativa.
                </p>
              </div>
            )}
          </div>

          <div className="mt-4 pt-3 border-t border-[#E5E7EB] text-xs text-[#4B5563]">
            {advisorData.length > 0 ? `Total asesores evaluados: ${advisorData.length}` : 'Sin datos de asesores'}
          </div>
        </div>
      </div>

      {/* GRÁFICO C & D: Tendencia en el tiempo y Proporción */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* GRÁFICO C: Tendencia Histórica / Temporal */}
        <div className="bg-white rounded-xl p-6 border border-[#E5E7EB] shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between pb-4 border-b border-[#E5E7EB]">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-[#F5C518]" />
              <h3 className="text-sm font-bold text-[#171717]">Evolución Temporal</h3>
            </div>
            <span className="text-xs text-[#4B5563]">{dateCol ? dateCol.header : 'Fechas'}</span>
          </div>

          <div className="mt-6 flex-1 flex flex-col justify-end">
            {timeData.length >= 2 ? (
              <div>
                {/* Visualización de tendencia de barras verticales o SVG línea */}
                {(() => {
                  const maxTimeVal = Math.max(...timeData.map((d) => d.value), 1);
                  return (
                    <div className="flex items-end justify-between gap-1.5 h-44 pt-4 px-2 border-b border-[#E5E7EB]">
                      {timeData.map((d, i) => {
                        const heightPct = (d.value / maxTimeVal) * 100;
                        return (
                          <div
                            key={i}
                            className="flex-1 flex flex-col items-center group relative h-full justify-end cursor-pointer"
                          >
                            {/* Barra */}
                            <div
                              className="w-full max-w-[28px] bg-[#F5C518] hover:bg-[#171717] rounded-t-sm transition-all duration-150"
                              style={{ height: `${Math.max(4, heightPct)}%` }}
                            />
                            {/* Etiqueta tooltip simple */}
                            <span className="text-[10px] text-[#4B5563] truncate mt-1 w-full text-center">
                              {d.date.length > 6 ? d.date.slice(-5) : d.date}
                            </span>
                            {/* Tooltip flotante al pasar mouse */}
                            <div className="absolute -top-8 bg-[#171717] text-white text-[11px] px-2 py-0.5 rounded shadow pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity z-10 whitespace-nowrap">
                              {d.date}: {formatNumber(d.value, 0)}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  );
                })()}
              </div>
            ) : (
              <div className="py-12 text-center text-xs text-[#4B5563] space-y-1">
                <Info className="w-6 h-6 mx-auto text-[#4B5563]/40" />
                <p>Sin suficientes registros con fechas para calcular tendencias históricas.</p>
                <p className="text-[11px] text-[#4B5563]/70">
                  Agrega registros fechados en Google Sheets para graficar la evolución.
                </p>
              </div>
            )}
          </div>

          <div className="mt-4 pt-3 border-t border-[#E5E7EB] text-xs text-[#4B5563]">
            {timeData.length > 0 ? `Periodos registrados: ${timeData.length}` : 'Sin datos temporales'}
          </div>
        </div>

        {/* GRÁFICO D: Distribución y Proporciones (Donut o Barras) */}
        <div className="bg-white rounded-xl p-6 border border-[#E5E7EB] shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between pb-4 border-b border-[#E5E7EB]">
            <div className="flex items-center gap-2">
              <PieChart className="w-5 h-5 text-[#F5C518]" />
              <h3 className="text-sm font-bold text-[#171717]">Distribución y Proporción</h3>
            </div>
            <span className="text-xs text-[#4B5563]">
              {groupCol ? groupCol.header : 'Segmentos'}
            </span>
          </div>

          <div className="mt-6">
            {distributionData.length > 0 ? (
              <div className="space-y-3.5">
                {distributionData.map((item, idx) => {
                  const colors = ['#F5C518', '#171717', '#4B5563', '#16A34A', '#F59E0B', '#9CA3AF'];
                  const currentColor = colors[idx % colors.length];

                  return (
                    <div key={idx} className="space-y-1">
                      <div className="flex justify-between items-center text-xs">
                        <div className="flex items-center gap-2 truncate max-w-[220px]">
                          <span
                            className="w-2.5 h-2.5 rounded-full shrink-0"
                            style={{ backgroundColor: currentColor }}
                          />
                          <span className="font-medium text-[#171717] truncate">{item.label}</span>
                        </div>
                        <div className="flex items-center gap-2 font-bold text-[#171717]">
                          <span>{formatNumber(item.value, 0)}</span>
                          <span className="text-[#4B5563] text-[11px] font-normal">
                            ({formatPercent(item.percent)})
                          </span>
                        </div>
                      </div>
                      <div className="h-2 w-full bg-[#F8F9FA] rounded-full overflow-hidden border border-[#E5E7EB]">
                        <div
                          className="h-full rounded-full transition-all duration-300"
                          style={{
                            width: `${Math.min(100, Math.max(2, item.percent))}%`,
                            backgroundColor: currentColor,
                          }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="py-12 text-center text-xs text-[#4B5563] space-y-1">
                <Info className="w-6 h-6 mx-auto text-[#4B5563]/40" />
                <p>Sin datos categóricos para mostrar proporciones.</p>
                <p className="text-[11px] text-[#4B5563]/70">
                  Se generará automáticamente cuando existan categorías o segmentos en la hoja.
                </p>
              </div>
            )}
          </div>

          <div className="mt-4 pt-3 border-t border-[#E5E7EB] text-xs text-[#4B5563]">
            {distributionData.length > 0 ? `${distributionData.length} categorías calculadas` : 'Sin categorías'}
          </div>
        </div>
      </div>
    </div>
  );
};
