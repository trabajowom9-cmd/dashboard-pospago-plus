import React from 'react';
import { Filter, RotateCcw, Calendar, User, Tag } from 'lucide-react';
import { ParsedColumn } from '../utils/dataParser';

interface FilterBarProps {
  columns: ParsedColumn[];
  availableAdvisors: string[];
  availableCategories: string[];
  selectedAdvisor: string;
  onSelectAdvisor: (val: string) => void;
  selectedCategory: string;
  onSelectCategory: (val: string) => void;
  startDate: string;
  onStartDateChange: (val: string) => void;
  endDate: string;
  onEndDateChange: (val: string) => void;
  onResetFilters: () => void;
  totalRecords: number;
  filteredCount: number;
}

export const FilterBar: React.FC<FilterBarProps> = ({
  columns,
  availableAdvisors,
  availableCategories,
  selectedAdvisor,
  onSelectAdvisor,
  selectedCategory,
  onSelectCategory,
  startDate,
  onStartDateChange,
  endDate,
  onEndDateChange,
  onResetFilters,
  totalRecords,
  filteredCount,
}) => {
  const hasDateCol = columns.some((c) => c.isDate);
  const hasAdvisorCol = availableAdvisors.length > 0;
  const hasCategoryCol = availableCategories.length > 0;

  const hasActiveFilters =
    Boolean(selectedAdvisor) || Boolean(selectedCategory) || Boolean(startDate) || Boolean(endDate);

  if (!hasAdvisorCol && !hasCategoryCol && !hasDateCol) {
    return null;
  }

  return (
    <div className="bg-white rounded-xl p-4 border border-[#E5E7EB] shadow-xs space-y-3">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-[#E5E7EB]">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-[#F5C518]" />
          <span className="text-xs font-bold uppercase tracking-wider text-[#171717]">
            Filtros Dinámicos
          </span>
          <span className="text-[11px] text-[#4B5563]">
            ({filteredCount} de {totalRecords} registros coincidentes)
          </span>
        </div>

        {hasActiveFilters && (
          <button
            onClick={onResetFilters}
            className="inline-flex items-center gap-1 text-xs text-[#DC2626] hover:text-[#B91C1C] font-semibold transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Restablecer todos los filtros</span>
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-1">
        {/* Filtro Asesor */}
        {hasAdvisorCol && (
          <div className="space-y-1">
            <label className="flex items-center gap-1.5 text-xs font-semibold text-[#171717]">
              <User className="w-3.5 h-3.5 text-[#F5C518]" />
              <span>Asesor / Responsable</span>
            </label>
            <select
              value={selectedAdvisor}
              onChange={(e) => onSelectAdvisor(e.target.value)}
              className="w-full px-3 py-1.5 text-xs border border-[#E5E7EB] rounded-lg bg-[#F8F9FA] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#F5C518] text-[#171717]"
            >
              <option value="">Todos los asesores</option>
              {availableAdvisors.map((adv) => (
                <option key={adv} value={adv}>
                  {adv}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Filtro Categoría */}
        {hasCategoryCol && (
          <div className="space-y-1">
            <label className="flex items-center gap-1.5 text-xs font-semibold text-[#171717]">
              <Tag className="w-3.5 h-3.5 text-[#F5C518]" />
              <span>Categoría / Segmento</span>
            </label>
            <select
              value={selectedCategory}
              onChange={(e) => onSelectCategory(e.target.value)}
              className="w-full px-3 py-1.5 text-xs border border-[#E5E7EB] rounded-lg bg-[#F8F9FA] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#F5C518] text-[#171717]"
            >
              <option value="">Todas las categorías</option>
              {availableCategories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Filtro Fecha Desde */}
        {hasDateCol && (
          <div className="space-y-1">
            <label className="flex items-center gap-1.5 text-xs font-semibold text-[#171717]">
              <Calendar className="w-3.5 h-3.5 text-[#F5C518]" />
              <span>Fecha Inicial</span>
            </label>
            <input
              type="date"
              value={startDate}
              onChange={(e) => onStartDateChange(e.target.value)}
              className="w-full px-3 py-1.5 text-xs border border-[#E5E7EB] rounded-lg bg-[#F8F9FA] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#F5C518] text-[#171717]"
            />
          </div>
        )}

        {/* Filtro Fecha Hasta */}
        {hasDateCol && (
          <div className="space-y-1">
            <label className="flex items-center gap-1.5 text-xs font-semibold text-[#171717]">
              <Calendar className="w-3.5 h-3.5 text-[#F5C518]" />
              <span>Fecha Final</span>
            </label>
            <input
              type="date"
              value={endDate}
              onChange={(e) => onEndDateChange(e.target.value)}
              className="w-full px-3 py-1.5 text-xs border border-[#E5E7EB] rounded-lg bg-[#F8F9FA] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#F5C518] text-[#171717]"
            />
          </div>
        )}
      </div>
    </div>
  );
};
