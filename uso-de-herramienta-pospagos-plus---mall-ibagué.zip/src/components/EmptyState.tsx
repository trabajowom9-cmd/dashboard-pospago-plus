import React from 'react';
import { Sheet, RefreshCw, PlusCircle, ExternalLink } from 'lucide-react';

interface EmptyStateProps {
  onRefresh: () => void;
  isUpdating: boolean;
  spreadsheetId: string;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  onRefresh,
  isUpdating,
  spreadsheetId,
}) => {
  return (
    <div className="space-y-6">
      {/* Banner Principal de Estado Vacío Obligatorio */}
      <div className="bg-white rounded-xl p-8 sm:p-12 border border-[#E5E7EB] shadow-xs text-center max-w-3xl mx-auto">
        <div className="w-14 h-14 bg-[#FFF4CC] border border-[#F5C518]/30 rounded-2xl flex items-center justify-center mx-auto mb-5 text-[#F5C518]">
          <Sheet className="w-7 h-7" />
        </div>

        <h3 className="text-lg sm:text-xl font-bold text-[#171717] mb-3">
          Aún no hay información registrada. Ingresa tus datos en Google Sheets para visualizar los indicadores y gráficos del dashboard.
        </h3>

        <p className="text-xs sm:text-sm text-[#4B5563] max-w-xl mx-auto mb-6">
          La hoja de cálculo está conectada en modo de solo lectura. Tan pronto como introduzcas registros de
          pospagos, asesores, fechas o metas en tu Google Sheets, el dashboard calculará automáticamente todos los
          indicadores y gráficos en tiempo real.
        </p>

        <div className="flex flex-wrap items-center justify-center gap-3">
          <button
            onClick={onRefresh}
            disabled={isUpdating}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg bg-[#F5C518] hover:bg-[#E0B212] text-[#171717] transition-colors shadow-xs cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${isUpdating ? 'animate-spin' : ''}`} />
            <span>Verificar si ya hay datos</span>
          </button>

          {spreadsheetId && (
            <a
              href={`https://docs.google.com/spreadsheets/d/${spreadsheetId}`}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-medium rounded-lg bg-white border border-[#E5E7EB] hover:bg-[#F8F9FA] text-[#171717] transition-colors shadow-xs"
            >
              <span>Abrir Google Sheets</span>
              <ExternalLink className="w-3.5 h-3.5 text-[#4B5563]" />
            </a>
          )}
        </div>
      </div>

      {/* Esqueletos estructurales que preservan el diseño visual sin inventar cifras */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <div
            key={i}
            className="bg-white rounded-xl p-5 border border-[#E5E7EB] shadow-xs flex flex-col justify-between opacity-80"
          >
            <div>
              <div className="flex justify-between items-center">
                <span className="text-xs font-semibold uppercase tracking-wider text-[#4B5563]">
                  Indicador {i}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#F8F9FA] text-[#4B5563] border border-[#E5E7EB]">
                  Pendiente
                </span>
              </div>
              <div className="mt-3 text-2xl font-bold text-[#E5E7EB]">--</div>
            </div>
            <div className="mt-4 pt-3 border-t border-[#E5E7EB] text-[11px] text-[#4B5563]">
              Esperando registros en Google Sheets
            </div>
          </div>
        ))}
      </div>

      {/* Espacios previstos para los gráficos */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl p-8 border border-[#E5E7EB] text-center text-[#4B5563] space-y-2 opacity-80">
          <p className="text-sm font-semibold text-[#171717]">Espacio reservado: Resultado vs Metas</p>
          <p className="text-xs">Este gráfico se activará al ingresar las metas y resultados en la hoja.</p>
        </div>
        <div className="bg-white rounded-xl p-8 border border-[#E5E7EB] text-center text-[#4B5563] space-y-2 opacity-80">
          <p className="text-sm font-semibold text-[#171717]">Espacio reservado: Rendimiento por Asesor</p>
          <p className="text-xs">Este gráfico se activará al registrar asesores y transacciones.</p>
        </div>
      </div>
    </div>
  );
};
