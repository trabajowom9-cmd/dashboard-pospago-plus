import React, { useState, useMemo } from 'react';
import { Search, ArrowUpDown, ArrowUp, ArrowDown, Download, Table as TableIcon } from 'lucide-react';
import { ParsedColumn, formatNumber, formatPercent } from '../utils/dataParser';

interface DataTableProps {
  headers: string[];
  columns: ParsedColumn[];
  records: Record<string, any>[];
  tableName?: string;
}

export const DataTable: React.FC<DataTableProps> = ({
  headers,
  columns,
  records,
  tableName = 'Registros de la hoja de cálculo',
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 15;

  // Filtrado por búsqueda de texto
  const filteredRecords = useMemo(() => {
    if (!searchTerm.trim()) return records;
    const term = searchTerm.toLowerCase().trim();
    return records.filter((rec) =>
      headers.some((h) => {
        const val = rec[h];
        if (val === null || val === undefined) return false;
        return String(val).toLowerCase().includes(term);
      })
    );
  }, [records, searchTerm, headers]);

  // Ordenamiento
  const sortedRecords = useMemo(() => {
    if (!sortField) return filteredRecords;
    return [...filteredRecords].sort((a, b) => {
      const valA = a[sortField];
      const valB = b[sortField];

      if (valA === null || valA === undefined) return 1;
      if (valB === null || valB === undefined) return -1;

      if (typeof valA === 'number' && typeof valB === 'number') {
        return sortDirection === 'asc' ? valA - valB : valB - valA;
      }

      return sortDirection === 'asc'
        ? String(valA).localeCompare(String(valB))
        : String(valB).localeCompare(String(valA));
    });
  }, [filteredRecords, sortField, sortDirection]);

  // Paginación
  const totalPages = Math.ceil(sortedRecords.length / pageSize) || 1;
  const paginatedRecords = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return sortedRecords.slice(start, start + pageSize);
  }, [sortedRecords, currentPage, pageSize]);

  const handleSort = (header: string) => {
    if (sortField === header) {
      if (sortDirection === 'asc') {
        setSortDirection('desc');
      } else {
        setSortField(null);
        setSortDirection('asc');
      }
    } else {
      setSortField(header);
      setSortDirection('asc');
    }
    setCurrentPage(1);
  };

  const exportCSV = () => {
    if (records.length === 0) return;
    const csvRows: string[] = [];
    csvRows.push(headers.map((h) => `"${h.replace(/"/g, '""')}"`).join(','));

    records.forEach((rec) => {
      const row = headers.map((h) => {
        const val = rec[h] ?? '';
        return `"${String(val).replace(/"/g, '""')}"`;
      });
      csvRows.push(row.join(','));
    });

    const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pospagos_plus_ibague_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-white rounded-xl border border-[#E5E7EB] shadow-xs overflow-hidden">
      {/* Barra de herramientas de la tabla */}
      <div className="p-4 sm:p-5 border-b border-[#E5E7EB] flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 bg-white">
        <div className="flex items-center gap-2">
          <TableIcon className="w-5 h-5 text-[#F5C518]" />
          <div>
            <h3 className="text-sm font-bold text-[#171717]">{tableName}</h3>
            <p className="text-xs text-[#4B5563]">
              {sortedRecords.length} de {records.length} registros cargados
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Campo de búsqueda */}
          <div className="relative flex-1 sm:w-64">
            <Search className="w-4 h-4 text-[#4B5563] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Buscar en registros..."
              className="w-full pl-9 pr-3 py-1.5 text-xs sm:text-sm border border-[#E5E7EB] rounded-lg bg-[#F8F9FA] focus:bg-white focus:outline-none focus:ring-2 focus:ring-[#F5C518] text-[#171717]"
            />
          </div>

          {/* Exportar */}
          <button
            onClick={exportCSV}
            title="Descargar datos en formato CSV"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg border border-[#E5E7EB] bg-white hover:bg-[#F8F9FA] text-[#171717] transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-[#F5C518]" />
            <span className="hidden sm:inline">Exportar CSV</span>
          </button>
        </div>
      </div>

      {/* Contenedor responsivo de la tabla */}
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse text-xs">
          <thead>
            <tr className="bg-[#F8F9FA] border-b border-[#E5E7EB]">
              {headers.map((header) => {
                const colInfo = columns.find((c) => c.header === header);
                const isNumeric = colInfo?.type === 'numeric' || colInfo?.type === 'percentage';
                const isSorted = sortField === header;

                return (
                  <th
                    key={header}
                    onClick={() => handleSort(header)}
                    className={`py-3 px-4 font-semibold text-[#171717] whitespace-nowrap cursor-pointer hover:bg-[#E5E7EB]/50 transition-colors select-none ${
                      isNumeric ? 'text-right' : 'text-left'
                    }`}
                  >
                    <div
                      className={`inline-flex items-center gap-1.5 ${
                        isNumeric ? 'justify-end' : 'justify-start'
                      }`}
                    >
                      <span>{header}</span>
                      {isSorted ? (
                        sortDirection === 'asc' ? (
                          <ArrowUp className="w-3 h-3 text-[#F5C518]" />
                        ) : (
                          <ArrowDown className="w-3 h-3 text-[#F5C518]" />
                        )
                      ) : (
                        <ArrowUpDown className="w-3 h-3 text-[#4B5563]/40" />
                      )}
                    </div>
                  </th>
                );
              })}
            </tr>
          </thead>
          <tbody className="divide-y divide-[#E5E7EB]">
            {paginatedRecords.length > 0 ? (
              paginatedRecords.map((row, rIdx) => (
                <tr
                  key={row._id ?? rIdx}
                  className="hover:bg-[#F8F9FA] transition-colors"
                >
                  {headers.map((header) => {
                    const val = row[header];
                    const colInfo = columns.find((c) => c.header === header);
                    const isNumeric = colInfo?.type === 'numeric';
                    const isPercent = colInfo?.type === 'percentage';

                    let formatted = val !== null && val !== undefined ? String(val) : '-';
                    if (typeof val === 'number') {
                      if (isPercent) {
                        formatted = formatPercent(val);
                      } else {
                        formatted = formatNumber(val, val % 1 !== 0 ? 1 : 0);
                      }
                    }

                    return (
                      <td
                        key={header}
                        className={`py-2.5 px-4 text-[#171717] whitespace-nowrap ${
                          isNumeric || isPercent ? 'text-right font-medium' : 'text-left'
                        }`}
                      >
                        {formatted}
                      </td>
                    );
                  })}
                </tr>
              ))
            ) : (
              <tr>
                <td
                  colSpan={headers.length || 1}
                  className="py-12 text-center text-xs text-[#4B5563]"
                >
                  No se encontraron registros que coincidan con la búsqueda.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Paginación */}
      {totalPages > 1 && (
        <div className="p-3.5 bg-[#F8F9FA] border-t border-[#E5E7EB] flex items-center justify-between text-xs text-[#4B5563]">
          <span>
            Página {currentPage} de {totalPages} ({sortedRecords.length} filas)
          </span>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="px-2.5 py-1 rounded bg-white border border-[#E5E7EB] text-[#171717] disabled:opacity-40 transition-colors cursor-pointer"
            >
              Anterior
            </button>
            <button
              onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="px-2.5 py-1 rounded bg-white border border-[#E5E7EB] text-[#171717] disabled:opacity-40 transition-colors cursor-pointer"
            >
              Siguiente
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
