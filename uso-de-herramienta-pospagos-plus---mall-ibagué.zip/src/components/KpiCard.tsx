import React from 'react';
import { TrendingUp, TrendingDown, Target, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { KpiItem, formatNumber, formatPercent } from '../utils/dataParser';

interface KpiCardProps {
  kpi: KpiItem;
  isPrimary?: boolean;
}

export const KpiCard: React.FC<KpiCardProps> = ({ kpi, isPrimary = false }) => {
  if (!kpi.hasSufficientData) {
    return (
      <div className="bg-white rounded-xl p-5 border border-[#E5E7EB] shadow-xs flex flex-col justify-between">
        <div>
          <span className="text-xs font-semibold uppercase tracking-wider text-[#4B5563]">
            {kpi.name}
          </span>
          <div className="mt-3 text-lg font-medium text-[#4B5563]">
            Sin datos suficientes
          </div>
        </div>
        <div className="mt-4 pt-3 border-t border-[#E5E7EB] text-[11px] text-[#4B5563]">
          Registra valores en Google Sheets para calcular
        </div>
      </div>
    );
  }

  // Formato del valor actual
  const displayActual = kpi.isPercentage
    ? formatPercent(kpi.actual)
    : kpi.isCurrency
    ? `$${formatNumber(kpi.actual, 0)}`
    : formatNumber(kpi.actual, kpi.actual % 1 !== 0 ? 1 : 0);

  // Formato de meta
  const displayMeta = kpi.meta !== null
    ? kpi.isPercentage
      ? formatPercent(kpi.meta)
      : kpi.isCurrency
      ? `$${formatNumber(kpi.meta, 0)}`
      : formatNumber(kpi.meta, kpi.meta % 1 !== 0 ? 1 : 0)
    : null;

  // Estado del cumplimiento
  let statusColor = 'text-[#4B5563]';
  let badgeBg = 'bg-[#F8F9FA] text-[#4B5563] border-[#E5E7EB]';
  let progressColor = 'bg-[#F5C518]';

  if (kpi.complianceRate !== null) {
    if (kpi.complianceRate >= 100) {
      statusColor = 'text-[#16A34A]';
      badgeBg = 'bg-[#16A34A]/10 text-[#16A34A] border-[#16A34A]/20';
      progressColor = 'bg-[#16A34A]';
    } else if (kpi.complianceRate >= 80) {
      statusColor = 'text-[#F59E0B]';
      badgeBg = 'bg-[#F59E0B]/10 text-[#F59E0B] border-[#F59E0B]/20';
      progressColor = 'bg-[#F5C518]';
    } else {
      statusColor = 'text-[#DC2626]';
      badgeBg = 'bg-[#DC2626]/10 text-[#DC2626] border-[#DC2626]/20';
      progressColor = 'bg-[#DC2626]';
    }
  }

  const progressPercent = kpi.complianceRate !== null ? Math.min(100, Math.max(0, kpi.complianceRate)) : null;

  return (
    <div
      className={`bg-white rounded-xl p-5 border transition-all duration-150 shadow-xs hover:shadow-sm flex flex-col justify-between ${
        isPrimary ? 'border-[#F5C518] ring-1 ring-[#F5C518]/20' : 'border-[#E5E7EB]'
      }`}
    >
      <div>
        {/* Encabezado de la tarjeta */}
        <div className="flex items-start justify-between gap-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-[#4B5563] line-clamp-1">
            {kpi.name}
          </span>
          {kpi.complianceRate !== null && (
            <span
              className={`inline-flex items-center text-xs font-bold px-2 py-0.5 rounded-full border ${badgeBg}`}
            >
              {formatPercent(kpi.complianceRate)}
            </span>
          )}
        </div>

        {/* Cifra destacada */}
        <div className="mt-3 flex items-baseline gap-2">
          <span className="text-2xl sm:text-3xl font-extrabold tracking-tight text-[#171717]">
            {displayActual}
          </span>
          {kpi.unit && <span className="text-xs text-[#4B5563] font-medium">{kpi.unit}</span>}
        </div>

        {/* Barra de progreso de cumplimiento (cuando hay meta) */}
        {progressPercent !== null && (
          <div className="mt-3 space-y-1">
            <div className="w-full bg-[#E5E7EB] rounded-full h-2 overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-300 ${progressColor}`}
                style={{ width: `${progressPercent}%` }}
              ></div>
            </div>
            <div className="flex items-center justify-between text-[11px] text-[#4B5563] pt-0.5">
              <span>0%</span>
              <span className="font-medium text-[#171717]">Meta: {displayMeta}</span>
              <span>100%</span>
            </div>
          </div>
        )}
      </div>

      {/* Métricas secundarias: Brecha, Pendiente, Variación */}
      <div className="mt-4 pt-3 border-t border-[#E5E7EB] space-y-1.5 text-xs">
        {kpi.meta !== null && (
          <div className="flex items-center justify-between text-[#4B5563]">
            <span className="flex items-center gap-1">
              <Target className="w-3.5 h-3.5 text-[#F5C518]" />
              <span>Brecha vs Meta:</span>
            </span>
            <span
              className={`font-semibold ${
                kpi.gap !== null && kpi.gap >= 0 ? 'text-[#16A34A]' : 'text-[#DC2626]'
              }`}
            >
              {kpi.gap !== null && kpi.gap > 0 ? '+' : ''}
              {kpi.isCurrency ? `$${formatNumber(kpi.gap, 0)}` : formatNumber(kpi.gap, 0)}
            </span>
          </div>
        )}

        {kpi.pending !== null && kpi.pending > 0 && (
          <div className="flex items-center justify-between text-[#4B5563]">
            <span>Pendiente por alcanzar:</span>
            <span className="font-semibold text-[#171717]">
              {kpi.isCurrency ? `$${formatNumber(kpi.pending, 0)}` : formatNumber(kpi.pending, 0)}
            </span>
          </div>
        )}

        {/* Variación temporal si existen datos históricos */}
        {kpi.percentageChange !== null && (
          <div className="flex items-center justify-between pt-0.5">
            <span className="text-[#4B5563]">Variación periodo:</span>
            <span
              className={`inline-flex items-center gap-0.5 font-semibold text-[11px] ${
                kpi.percentageChange >= 0 ? 'text-[#16A34A]' : 'text-[#DC2626]'
              }`}
            >
              {kpi.percentageChange >= 0 ? (
                <TrendingUp className="w-3 h-3" />
              ) : (
                <TrendingDown className="w-3 h-3" />
              )}
              <span>
                {kpi.percentageChange >= 0 ? '+' : ''}
                {formatPercent(kpi.percentageChange)}
              </span>
            </span>
          </div>
        )}

        {kpi.meta === null && kpi.percentageChange === null && (
          <div className="text-[11px] text-[#4B5563] italic">
            Registros analizados: {kpi.recordCount}
          </div>
        )}
      </div>
    </div>
  );
};
