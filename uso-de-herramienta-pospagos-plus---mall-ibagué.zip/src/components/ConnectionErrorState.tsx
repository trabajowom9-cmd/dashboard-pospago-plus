import React from 'react';
import { AlertCircle, Key, Database, RefreshCw } from 'lucide-react';

interface ConnectionErrorStateProps {
  errorMessage: string;
  onRetry: () => void;
  onOpenConfig: () => void;
  onSignIn: () => void;
  isSignedIn: boolean;
  isRetrying: boolean;
}

export const ConnectionErrorState: React.FC<ConnectionErrorStateProps> = ({
  errorMessage,
  onRetry,
  onOpenConfig,
  onSignIn,
  isSignedIn,
  isRetrying,
}) => {
  const isAuthIssue =
    errorMessage.toLowerCase().includes('inicia sesión') ||
    errorMessage.toLowerCase().includes('permiso') ||
    errorMessage.toLowerCase().includes('expir') ||
    errorMessage.toLowerCase().includes('autenticación') ||
    errorMessage.toLowerCase().includes('403') ||
    errorMessage.toLowerCase().includes('401');

  const isNoSheetConfigured =
    errorMessage.toLowerCase().includes('inválido') ||
    errorMessage.toLowerCase().includes('configur') ||
    errorMessage.toLowerCase().includes('no encontrada');

  return (
    <div className="bg-white rounded-xl p-8 sm:p-12 border border-[#E5E7EB] shadow-xs max-w-2xl mx-auto text-center space-y-6">
      <div className="w-14 h-14 bg-[#DC2626]/10 text-[#DC2626] border border-[#DC2626]/20 rounded-2xl flex items-center justify-center mx-auto">
        <AlertCircle className="w-7 h-7" />
      </div>

      <div className="space-y-2">
        <h3 className="text-lg sm:text-xl font-bold text-[#171717]">
          Estado de Conexión con Google Sheets
        </h3>
        <p className="text-sm text-[#DC2626] font-medium bg-[#DC2626]/5 py-2 px-4 rounded-lg inline-block">
          {errorMessage}
        </p>
      </div>

      <div className="text-xs sm:text-sm text-[#4B5563] text-left bg-[#F8F9FA] p-4 rounded-lg border border-[#E5E7EB] space-y-2">
        <p className="font-semibold text-[#171717]">Para resolver este estado:</p>
        <ol className="list-decimal pl-5 space-y-1.5 text-xs text-[#4B5563]">
          <li>
            Haz clic en <strong>"Google Sheet"</strong> e ingresa el enlace completo o ID de tu hoja de cálculo.
          </li>
          {!isSignedIn && (
            <li>
              Si la hoja de cálculo es privada, haz clic en <strong>"Acceder con Google"</strong> con la cuenta que tiene acceso a la hoja.
            </li>
          )}
          <li>
            Si prefieres acceso directo sin iniciar sesión, en Google Sheets ve a <em>Compartir &gt; Cualquier persona con el enlace &gt; Lector</em>.
          </li>
          <li>
            La aplicación únicamente leerá los datos existentes para calcular indicadores en tiempo real.
          </li>
        </ol>
      </div>

      <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
        {!isSignedIn && isAuthIssue && (
          <button
            onClick={onSignIn}
            className="inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg bg-white border border-[#E5E7EB] hover:bg-[#F8F9FA] text-[#171717] transition-all shadow-xs cursor-pointer"
          >
            <Key className="w-4 h-4 text-[#F5C518]" />
            <span>Acceder con Google</span>
          </button>
        )}

        <button
          onClick={onOpenConfig}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-semibold rounded-lg bg-[#F5C518] hover:bg-[#E0B212] text-[#171717] transition-colors shadow-xs cursor-pointer"
        >
          <Database className="w-4 h-4" />
          <span>Configurar Enlace de Google Sheets</span>
        </button>

        <button
          onClick={onRetry}
          disabled={isRetrying}
          className="inline-flex items-center gap-2 px-4 py-2 text-xs sm:text-sm font-medium rounded-lg bg-white border border-[#E5E7EB] hover:bg-[#F8F9FA] text-[#171717] transition-colors cursor-pointer disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${isRetrying ? 'animate-spin' : ''}`} />
          <span>Reintentar conexión</span>
        </button>
      </div>
    </div>
  );
};
