import React, { useState } from 'react';
import { X, ExternalLink, Sheet, Check, AlertCircle, RefreshCw } from 'lucide-react';
import { extractSpreadsheetId, SheetTab } from '../services/googleSheets';

interface SheetConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  spreadsheetId: string;
  tabTitle: string;
  tabs: SheetTab[];
  onSave: (newId: string, newTab: string) => void;
  isTesting: boolean;
  onTestConnection: (id: string) => Promise<boolean>;
}

export const SheetConfigModal: React.FC<SheetConfigModalProps> = ({
  isOpen,
  onClose,
  spreadsheetId,
  tabTitle,
  tabs,
  onSave,
  isTesting,
  onTestConnection,
}) => {
  const [inputValue, setInputValue] = useState(spreadsheetId);
  const [selectedTab, setSelectedTab] = useState(tabTitle);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  if (!isOpen) return null;

  const handleTest = async () => {
    const cleanId = extractSpreadsheetId(inputValue);
    if (!cleanId) {
      setTestResult({ success: false, message: 'Ingresa un enlace o ID válido de Google Sheets' });
      return;
    }

    try {
      const ok = await onTestConnection(cleanId);
      if (ok) {
        setTestResult({ success: true, message: '¡Conexión verificada exitosamente!' });
      } else {
        setTestResult({ success: false, message: 'No se pudo conectar. Verifica permisos o inicia sesión.' });
      }
    } catch (err: any) {
      setTestResult({ success: false, message: err.message || 'Error al conectar' });
    }
  };

  const handleSave = () => {
    const cleanId = extractSpreadsheetId(inputValue);
    if (!cleanId) return;
    onSave(cleanId, selectedTab || 'Hoja 1');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs">
      <div className="bg-white rounded-xl shadow-xl border border-[#E5E7EB] max-w-lg w-full overflow-hidden">
        {/* Header del Modal */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-[#E5E7EB] bg-[#F8F9FA]">
          <div className="flex items-center gap-2">
            <Sheet className="w-5 h-5 text-[#F5C518]" />
            <h3 className="text-base font-bold text-[#171717]">Configurar Google Sheets</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-md text-[#4B5563] hover:text-[#171717] hover:bg-[#E5E7EB] transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Contenido */}
        <div className="p-6 space-y-5">
          {/* Instrucciones claras */}
          <div className="bg-[#FFF4CC] border border-[#F5C518]/40 rounded-lg p-3.5 text-xs text-[#171717] space-y-1">
            <p className="font-semibold text-[#171717]">Fuente oficial de datos:</p>
            <p className="text-[#4B5563]">
              Pega el enlace o ID de tu hoja de Google Sheets donde registras la herramienta pospagos PLUS de Mall Ibagué.
            </p>
            <p className="text-[#171717] font-medium text-[11px] pt-1">
              🔒 <strong>Garantía de Solo Lectura:</strong> La aplicación jamás modificará ni escribirá en tu hoja.
            </p>
          </div>

          {/* Campo de Enlace o ID */}
          <div className="space-y-1.5">
            <label className="block text-xs font-semibold text-[#171717]">
              Enlace o ID de la hoja de Google Sheets
            </label>
            <input
              type="text"
              value={inputValue}
              onChange={(e) => {
                setInputValue(e.target.value);
                setTestResult(null);
              }}
              placeholder="https://docs.google.com/spreadsheets/d/1BxiMVs0X... o el ID directo"
              className="w-full px-3.5 py-2 text-sm border border-[#E5E7EB] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#F5C518] focus:border-transparent bg-white text-[#171717]"
            />
            <p className="text-[11px] text-[#4B5563]">
              Ejemplo: <code>https://docs.google.com/spreadsheets/d/1a2B3c.../edit</code>
            </p>
          </div>

          {/* Selector de Pestaña / Hoja si hay pestañas disponibles */}
          {tabs.length > 0 && (
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-[#171717]">
                Pestaña a consultar ({tabs.length} disponibles)
              </label>
              <select
                value={selectedTab}
                onChange={(e) => setSelectedTab(e.target.value)}
                className="w-full px-3.5 py-2 text-sm border border-[#E5E7EB] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#F5C518] focus:border-transparent bg-white text-[#171717]"
              >
                {tabs.map((tab) => (
                  <option key={tab.id} value={tab.title}>
                    {tab.title} {tab.rowCount ? `(${tab.rowCount} filas)` : ''}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Resultado de prueba */}
          {testResult && (
            <div
              className={`p-3 rounded-lg text-xs flex items-center gap-2 ${
                testResult.success
                  ? 'bg-[#16A34A]/10 text-[#16A34A] border border-[#16A34A]/20'
                  : 'bg-[#DC2626]/10 text-[#DC2626] border border-[#DC2626]/20'
              }`}
            >
              {testResult.success ? (
                <Check className="w-4 h-4 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 shrink-0" />
              )}
              <span>{testResult.message}</span>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-[#F8F9FA] border-t border-[#E5E7EB] flex items-center justify-between">
          <button
            type="button"
            onClick={handleTest}
            disabled={isTesting || !inputValue.trim()}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg text-[#171717] bg-white border border-[#E5E7EB] hover:bg-[#F8F9FA] transition-colors disabled:opacity-50 cursor-pointer"
          >
            {isTesting && <RefreshCw className="w-3.5 h-3.5 animate-spin text-[#F5C518]" />}
            <span>Probar conexión</span>
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-3.5 py-1.5 text-xs font-medium text-[#4B5563] hover:text-[#171717] transition-colors cursor-pointer"
            >
              Cancelar
            </button>
            <button
              type="button"
              onClick={handleSave}
              disabled={!inputValue.trim()}
              className="px-4 py-1.5 text-xs font-semibold text-[#171717] bg-[#F5C518] hover:bg-[#E0B212] rounded-lg transition-colors disabled:opacity-50 shadow-xs cursor-pointer"
            >
              Guardar y sincronizar
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
